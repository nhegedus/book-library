import type { IAuthData, IAuth } from "./Auth.types";

export class Auth implements IAuth {
    first_name: string;
    last_name: string;
    password: string;
    email: string;
    token?: string | undefined;

    constructor(data: IAuthData) {
        this.validate(data);
        this.email = data.email;
        this.first_name = data.first_name;
        this.last_name = data.last_name;
        this.password = data.password;
        this.token = data.token;
    }

    validate(data: IAuthData): void {
        if (!data.email || !data.password) {
            throw new Error("Invalid data");
        }
    }
}