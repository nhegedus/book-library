export interface IAuthData {
    first_name: string;
    last_name: string;
    email: string;
    password: string;
    token?: string;
}

export interface IAuth extends IAuthData {
    validate(data: IAuthData): void;
}

export interface IAuthRepository {
    login(data: IAuthData): void,
    register(data: IAuthData): void,
    logout(): void,
}