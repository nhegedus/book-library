import type { IAuthData, IAuthRepository } from "../domain/Auth.types";

export class AuthService implements IAuthRepository {

   login(data: IAuthData): void {
       
   } 
   
   register(data: IAuthData): void {
       
   }

   logout(): void {
       
   }
}