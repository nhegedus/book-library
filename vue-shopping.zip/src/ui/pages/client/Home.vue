<script setup lang="ts">
</script>

<template>
  <main>
    Home
  </main>
</template>
