import { AuthService } from "@/modules/auth/infrastructure/AuthService";
const auth = {
    namespaced: true,
    state: () => ({
      user: {},
      token: null,
    }),
    getters: {
      
    },
    actions: {
        loginUser(context: any, payload: any) {
            console.log('do login');
            
        }
    },
    mutations: {
      
    },
    
  }

  export default auth;