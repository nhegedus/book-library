import { createRouter, createWebHistory } from 'vue-router'
import Home from '@ui/pages/client/Home.vue';

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'layout',
      component: () => import('@ui/layout/DefaultLayout.vue'),
      children: [
        {
          path: '/',
          name: 'home',
          component: Home
        },
        {
          path: '/about',
          name: 'about',
          // route level code-splitting
          // this generates a separate chunk (About.[hash].js) for this route
          // which is lazy-loaded when the route is visited.
          component: () => import('@ui/pages/client/About.vue')
        },
      ]
    },
    {
      path: '/auth',
      name: 'auth',
      redirect: '/auth/login',
      component: () => import('@ui/layout/AuthLayout.vue'),
      children: [
        {
          path: '/auth/login',
          name: 'login',
          component: () => import('@ui/pages/admin/auth/Login.vue')
        },
        {
          path: '/auth/register',
          name: 'register',
          component: () => import('@ui/pages/admin/auth/Register.vue')
        },
      ]
    },
  ]
})

export default router
